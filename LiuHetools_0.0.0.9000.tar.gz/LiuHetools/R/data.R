
           #' This is data to be included in my package
           #'
           #'
           #' @references \url{http://www.stat.umn.edu/geyer/3701/data/p4p3.csv}
           "x" 
           #' @references \url{"http://www.stat.umn.edu/geyer/3701/data/q1p1.txt"}
           "quiz11" 
           #' @references \url{"http://www.stat.umn.edu/geyer/3701/data/q1p1.txt"}
           "quiz12"
           #' @references \url{"http://www.stat.umn.edu/geyer/3701/data/q1p3.txt"}
           "quiz13" 
           #' @references \url{"http://www.stat.umn.edu/geyer/3701/data/q1p4.txt"}
           "hw14" 
           #' @references \url{"http://www.stat.umn.edu/geyer/3701/data/q1p4.txt"}
           "hw15"
           #' @references \url{"http://www.stat.umn.edu/geyer/3701/data/q2p1.rda"}
           "quiz21a" 
           #' @references \url{"http://www.stat.umn.edu/geyer/3701/data/q2p1.rda"}
           "quiz21x" 
           #' @references \url{"http://www.stat.umn.edu/geyer/3701/data/q2p3.rda"}
           "quiz23"
           #' @references \url{"http://www.stat.umn.edu/geyer/3701/data/q2p6.rda"}
           "hw26"           
           
           
          
           
           
           
           
           
           
